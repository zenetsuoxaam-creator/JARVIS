package com.jarvis.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Home screen widget: ek button bolne ke liye, ek monster (hologram) page ke liye. */
class JarvisWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_jarvis)
            v.setOnClickPendingIntent(R.id.btn_voice,
                pi(ctx, Intent(ctx, MainActivity::class.java).putExtra("voice", true), 1))
            v.setOnClickPendingIntent(R.id.btn_monster, pi(ctx, Intent(ctx, MonsterActivity::class.java), 2))
            mgr.updateAppWidget(id, v)
        }
    }

    private fun pi(ctx: Context, i: Intent, rc: Int): PendingIntent =
        PendingIntent.getActivity(ctx, rc, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

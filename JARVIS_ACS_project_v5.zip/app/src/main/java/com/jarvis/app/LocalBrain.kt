package com.jarvis.app

/** Bina API ke chhote-mote dost wale jawab. API bachane ke liye pehle yahi check hota hai. */
object LocalBrain {
    private val greets = listOf(
        "Arre aa gaya tu! Kya haal hai?",
        "Oye, zinda hai ya bhoot ban gaya? 😄",
        "Bhai, teri hi kami thi! Bata kya scene hai?"
    )
    private val roasts = listOf(
        "Abe saale, itna dimaag lagaya hota to aaj tu Google ka boss hota 😏",
        "Tera sawaal itna slow hai ki WiFi bhi sharma jaye, saale 😂",
        "Bhai, tu bolta hai to lagta hai Bluetooth connect ho raha hai 😆"
    )
    private val jokes = listOf(
        "Computer ne chai kyun pi? Kyunki usne Java ko cup mein daal diya! 😄"
    )

    fun reply(raw: String): Pair<Mood, String>? {
        val t = raw.lowercase()
        return when {
            Regex("^(hi|hello|hey|oye|namaste|hii+)\\b").containsMatchIn(t) ||
                Regex("kya haal|kaisa hai|kaise ho").containsMatchIn(t) ->
                Mood.HAPPY to greets.random()
            Regex("thank|shukriya|dhanyavaad").containsMatchIn(t) ->
                Mood.LOVING to "Arre yaar, shukriya kaisa! Tu hai to main hoon 😊"
            Regex("\\bbore\\b|bored|bore ho").containsMatchIn(t) ->
                Mood.EXCITED to ("Chal, joke sunata hoon: " + jokes.random())
            Regex("gaali|gali de").containsMatchIn(t) ->
                Mood.SASSY to roasts.random()
            Regex("\\bmood\\b").containsMatchIn(t) ->
                Mood.CHILL to "Mera mood abhi ${Persona.mood.name.lowercase()} hai ${Persona.mood.emoji}. Tera kya scene hai?"
            else -> null
        }
    }
}

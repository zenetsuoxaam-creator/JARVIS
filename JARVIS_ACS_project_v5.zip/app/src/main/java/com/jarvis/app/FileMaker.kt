package com.jarvis.app

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** PDF (Android built-in), DOCX aur XLSX (zip mein XML, koi library nahi). */
object FileMaker {
    private fun dir(ctx: Context): File = (ctx.getExternalFilesDir(null) ?: ctx.filesDir).also { it.mkdirs() }
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun safe(s: String) = s.take(30).replace(Regex("[^A-Za-z0-9_-]+"), "_").ifEmpty { "file" }
    private const val XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"

    fun pdf(ctx: Context, title: String, body: String): File {
        val doc = PdfDocument()
        val paint = Paint().apply { textSize = 12f; isAntiAlias = true }
        val w = 595; val h = 842; val margin = 40f
        val lines = body.lines().flatMap { it.chunked(90).ifEmpty { listOf("") } }
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
        paint.textSize = 18f
        page.canvas.drawText(title, margin, margin + 20, paint)
        paint.textSize = 12f
        var y = margin + 50
        for (l in lines) {
            if (y > h - margin) {
                doc.finishPage(page); pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create()); y = margin
            }
            page.canvas.drawText(l, margin, y, paint); y += 18
        }
        doc.finishPage(page)
        val f = File(dir(ctx), safe(title) + ".pdf")
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        return f
    }

    fun docx(ctx: Context, title: String, body: String): File {
        val paras = (listOf(title) + body.lines()).joinToString("") {
            "<w:p><w:r><w:t xml:space=\"preserve\">${esc(it)}</w:t></w:r></w:p>"
        }
        val doc = "$XML<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>$paras<w:sectPr/></w:body></w:document>"
        val ct = "$XML<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>"
        val rels = "$XML<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>"
        return zip(ctx, safe(title) + ".docx", linkedMapOf("[Content_Types].xml" to ct, "_rels/.rels" to rels, "word/document.xml" to doc))
    }

    /** csv = pehli line header, har line comma-separated. */
    fun xlsx(ctx: Context, title: String, csv: String): File {
        val rows = csv.lines().filter { it.isNotBlank() }.mapIndexed { r, line ->
            val cells = line.split(",").mapIndexed { c, v ->
                val ref = "${'A' + c}${r + 1}"
                "<c r=\"$ref\" t=\"inlineStr\"><is><t>${esc(v.trim())}</t></is></c>"
            }.joinToString("")
            "<row r=\"${r + 1}\">$cells</row>"
        }.joinToString("")
        val sheet = "$XML<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>$rows</sheetData></worksheet>"
        val wb = "$XML<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
        val wbRels = "$XML<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>"
        val ct = "$XML<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
            "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>"
        val rels = "$XML<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"
        return zip(ctx, safe(title) + ".xlsx", linkedMapOf(
            "[Content_Types].xml" to ct, "_rels/.rels" to rels,
            "xl/workbook.xml" to wb, "xl/_rels/workbook.xml.rels" to wbRels,
            "xl/worksheets/sheet1.xml" to sheet))
    }

    private fun zip(ctx: Context, name: String, parts: Map<String, String>): File {
        val f = File(dir(ctx), name)
        ZipOutputStream(FileOutputStream(f)).use { z ->
            for ((p, c) in parts) {
                z.putNextEntry(ZipEntry(p)); z.write(c.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
        }
        return f
    }
}

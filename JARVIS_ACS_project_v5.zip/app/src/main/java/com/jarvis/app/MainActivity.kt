package com.jarvis.app

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

private const val BG = "#F9F8F5"
private const val INK = "#1F1E1D"
private const val MUTED = "#8A8782"
private const val BORDER = "#E3DFD6"
private const val ORANGE = "#D97757"

/**
 * JARVIS HOME: Claude jaisa saaf screen.
 *  - Upar ☰ (settings) aur 👾 (monster kholne ka button)
 *  - Beech mein "Happy Monday, Ayush" + orange sparkle
 *  - Neeche type box, [+] photo, [↑] send, aur 🎤 voice-talk (type box ke bagal mein)
 * Har jawab likha bhi jaata hai aur bola bhi jaata hai.
 */
class MainActivity : android.app.Activity(), TextToSpeech.OnInitListener {

    private lateinit var greet: LinearLayout
    private lateinit var greetText: TextView
    private lateinit var chatScroll: ScrollView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var voiceBtn: TextView
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var sr: SpeechRecognizer? = null
    private var voiceMode = false          // 🎤 voice-talk: baat khatam hone par phir sunta hai
    private var voiceErrors = 0
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private val REQ_CAM = 7
    private var camQ = "Ye kya hai?"

    private val appPerms = arrayOf(
        Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS,
        Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA,
        "com.termux.permission.RUN_COMMAND",
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        val missing = appPerms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
        if (intent?.getBooleanExtra("voice", false) == true) ui.post { startListening() }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        ttsReady = true
        val hi = tts.setLanguage(Locale("hi", "IN"))
        if (hi == TextToSpeech.LANG_MISSING_DATA || hi == TextToSpeech.LANG_NOT_SUPPORTED) {
            val en = Locale("en", "IN")
            tts.language = if (tts.isLanguageAvailable(en) >= TextToSpeech.LANG_AVAILABLE) en else Locale.US
            addChat("Hindi awaaz phone mein nahi mili, English awaaz use ho rahi hai. Phone ki Text-to-Speech settings mein Hindi data install karo.")
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { ui.post { afterSpeech() } }
            override fun onError(id: String?) { ui.post { afterSpeech() } }
        })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radius: Float, stroke: Int): GradientDrawable =
        GradientDrawable().apply { setColor(fill); cornerRadius = radius; setStroke(dp(1), stroke) }

    private fun iconBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 22f
        setTextColor(Color.parseColor(INK))
        setPadding(dp(10), dp(6), dp(10), dp(6))
        setOnClickListener { onClick() }
    }

    private fun circleBtn(label: String, bg: Int, fg: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 18f
        gravity = Gravity.CENTER
        setTextColor(fg)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bg) }
        setOnClickListener { onClick() }
    }

    private fun greetingText(): String {
        val days = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val day = days[Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1]
        val name = prefs.getString("name", "Ayush")?.takeIf { it.isNotBlank() } ?: "Ayush"
        return "Happy $day, $name"
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor(BG))
        }

        // ---- upar ki bar: ☰ ... 👾 ----
        val top = FrameLayout(this).apply { setPadding(dp(12), dp(14), dp(12), dp(4)) }
        top.addView(iconBtn("☰") { showSettings() },
            FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))
        top.addView(iconBtn("👾") { startActivity(Intent(this, MonsterActivity::class.java)) },
            FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---- beech ka hissa: greeting ya chat ----
        val middle = FrameLayout(this)
        greet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(SparkView(this@MainActivity),
                LinearLayout.LayoutParams(dp(56), dp(56)).apply { bottomMargin = dp(22) })
            greetText = TextView(this@MainActivity).apply {
                text = greetingText()
                textSize = 26f
                gravity = Gravity.CENTER
                typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
                setTextColor(Color.parseColor(INK))
            }
            addView(greetText)
        }
        middle.addView(greet, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))

        chat = TextView(this).apply {
            setTextColor(Color.parseColor(INK))
            textSize = 15f
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        chatScroll = ScrollView(this).apply {
            visibility = View.GONE
            addView(chat)
        }
        middle.addView(chatScroll, FrameLayout.LayoutParams(-1, -1))
        root.addView(middle, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            setTextColor(Color.parseColor(MUTED))
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(4))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        // ---- neeche ka input card (Claude jaisa) ----
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, dp(28).toFloat(), Color.parseColor(BORDER))
            setPadding(dp(16), dp(12), dp(10), dp(10))
        }
        input = EditText(this).apply {
            hint = "JARVIS se baat karo..."
            setHintTextColor(Color.parseColor(MUTED))
            setTextColor(Color.parseColor(INK))
            textSize = 16f
            background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false
            }
        }
        card.addView(input, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        row.addView(circleBtn("+", Color.parseColor("#F1EFEA"), Color.parseColor(INK)) { openCamera("Ye kya hai?") },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(circleBtn("↑", Color.parseColor("#F1EFEA"), Color.parseColor(INK)) { sendTyped() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        voiceBtn = circleBtn("🎤", Color.parseColor(INK), Color.WHITE) { toggleVoiceMode() }
        row.addView(voiceBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(10) })
        card.addView(row, LinearLayout.LayoutParams(-1, -2))

        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(6), dp(14), dp(16)) })
        setContentView(root)
    }

    /** Pehla message aate hi greeting hat kar chat dikhti hai. */
    private fun addChat(s: String) {
        greet.visibility = View.GONE
        chatScroll.visibility = View.VISIBLE
        chat.append(s + "\n\n")
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setStatus(s: String) { status.text = s }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isNotEmpty()) { input.setText(""); handle(t) }
    }

    private fun say(t: String) {
        if (!ttsReady) { afterSpeech(); return }
        val m = Persona.mood
        tts.setPitch(when (m) { Mood.HAPPY, Mood.EXCITED -> 1.15f; Mood.SAD, Mood.TIRED -> 0.85f; else -> 1.0f })
        tts.setSpeechRate(when (m) { Mood.EXCITED, Mood.ANGRY -> 1.15f; Mood.TIRED, Mood.SAD -> 0.9f; else -> 1.0f })
        MonsterActivity.instance?.pushState("speaking", t)
        setStatus("Bol raha hoon…")
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    /** Bolna khatam hone ke baad: voice-talk ON ho to phir sunna shuru. */
    private fun afterSpeech() {
        MonsterActivity.instance?.pushState("idle")
        setStatus("")
        if (voiceMode) startListening()
    }

    private fun camFile() = File(getExternalFilesDir(null) ?: filesDir, "cam.jpg")

    private fun openCamera(q: String) {
        camQ = q
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", camFile())
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION), REQ_CAM)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAM || resultCode != RESULT_OK) return
        val bytes = camFile().readBytes()
        val q = camQ
        addChat("Tu: [photo] $q")
        setStatus("Photo dekh raha hoon…")
        io.execute {
            val r = CommandRouter.vision(this, bytes, q)
            ui.post {
                addChat("JARVIS ${r.mood?.emoji ?: ""}: ${r.text}")
                say(r.text)
            }
        }
    }

    private fun handle(text: String) {
        if (Regex("^(ye kya (hai|h)|dekh ke batao|photo lo|camera)", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
            openCamera(text); return
        }
        addChat("Tu: $text")
        setStatus("Soch raha hoon…")
        io.execute {
            val reply = CommandRouter.process(this, text)
            ui.post {
                addChat("JARVIS ${reply.mood?.emoji ?: ""}: ${reply.text}")
                say(reply.text)
            }
        }
    }

    private fun toggleVoiceMode() {
        voiceMode = !voiceMode
        voiceErrors = 0
        updateVoiceBtn()
        if (voiceMode) {
            startListening()
        } else {
            sr?.destroy(); sr = null
            tts.stop()
            setStatus("")
            MonsterActivity.instance?.pushState("idle")
        }
    }

    private fun updateVoiceBtn() {
        voiceBtn.text = if (voiceMode) "■" else "🎤"
        voiceBtn.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (voiceMode) Color.parseColor(ORANGE) else Color.parseColor(INK))
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        sr?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        sr = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                rec.destroy(); sr = null
                voiceErrors = 0
                val said = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (said.isNullOrBlank()) { afterSpeech(); return }
                handle(said)
            }
            override fun onError(error: Int) {
                rec.destroy(); sr = null
                if (!voiceMode) {
                    setStatus("")
                    addChat("Sun nahi paya, dobara bol.")
                    return
                }
                voiceErrors++
                if (voiceErrors >= 4) {               // lagatar awaaz nahi mili to voice mode band
                    voiceMode = false
                    updateVoiceBtn()
                    setStatus("Awaaz nahi mili, voice mode band.")
                    return
                }
                ui.postDelayed({ if (voiceMode) startListening() }, 700)
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        setStatus(if (voiceMode) "Sun raha hoon… (voice mode ON)" else "Sun raha hoon…")
        MonsterActivity.instance?.pushState("listening")
        rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        })
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val nameField = EditText(this).apply {
            hint = "Aapka naam (home par greeting mein aayega)"
            setText(prefs.getString("name", "Ayush"))
        }
        val keyField = EditText(this).apply { hint = "Gemini API key"; setText(SecurePrefs.geminiKey(this@MainActivity) ?: "") }
        val ctrlStatus = TextView(this).apply {
            text = "Phone control: " + if (JarvisAccessibilityService.instance != null) "ON ✅" else "OFF ❌"
        }
        box.addView(TextView(this).apply { text = "Naam" })
        box.addView(nameField)
        box.addView(TextView(this).apply { text = "API key (sirf sawal ke jawab ke liye use hoti hai)" })
        box.addView(keyField)
        box.addView(Button(this).apply {
            text = "Phone control allow karo (Accessibility)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        box.addView(Button(this).apply {
            text = "Brightness control allow karo"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                    .setData(android.net.Uri.parse("package:$packageName")))
            }
        })
        box.addView(Button(this).apply {
            text = "Notification access allow karo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        box.addView(Button(this).apply {
            text = "Wake word (\"Jarvis\") ON karo"
            setOnClickListener {
                val i = Intent(this@MainActivity, WakeService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
        })
        val smart = Button(this)
        fun refreshSmart() {
            smart.text = "Message padh ke batao: " + if (prefs.getBoolean("smart_read", false)) "ON ✅" else "OFF ❌"
        }
        smart.setOnClickListener {
            prefs.edit().putBoolean("smart_read", !prefs.getBoolean("smart_read", false)).apply()
            refreshSmart()
        }
        refreshSmart()
        box.addView(smart)
        box.addView(ctrlStatus)
        AlertDialog.Builder(this).setTitle("Settings").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val name = nameField.text.toString().trim().ifEmpty { "Ayush" }
                prefs.edit().putString("name", name).apply()
                greetText.text = greetingText()
                SecurePrefs.setGeminiKey(this@MainActivity, keyField.text.toString().trim())
            }
            .setNegativeButton("Band", null)
            .show()
    }

    override fun onDestroy() {
        sr?.destroy()
        tts.shutdown()
        io.shutdown()
        MonsterActivity.instance?.finish()
        super.onDestroy()
    }
}

/** Orange sparkle (Claude jaisa). Canvas par 12 rounded lines. */
private class SparkView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor(ORANGE)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f * 0.95f
        paint.strokeWidth = r * 0.13f
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0 + 8.0)
            val len = if (i % 2 == 0) r else r * 0.78f
            val inner = r * 0.22f
            c.drawLine(
                cx + inner * Math.cos(a).toFloat(), cy + inner * Math.sin(a).toFloat(),
                cx + len * Math.cos(a).toFloat(), cy + len * Math.sin(a).toFloat(), paint
            )
        }
    }
}

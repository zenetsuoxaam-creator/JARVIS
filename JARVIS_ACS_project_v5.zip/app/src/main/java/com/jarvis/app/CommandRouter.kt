package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Reply(val text: String, val mood: Mood? = null)

object CommandRouter {
    private val history = ArrayList<Pair<String, String>>() // role, text
    private const val NO_SERVICE = "Phone control ON nahi hai. Settings (⚙) mein Accessibility ON karo."

    /** Background thread par chalta hai. Order: device commands -> local dost wale jawab -> Gemini. */
    fun process(ctx: Context, raw: String): Reply {
        val t = raw.trim()
        Persona.moodFromUser(t)?.let { Persona.mood = it }
        device(ctx, t)?.let { return Reply(it, Persona.mood) }
        LocalBrain.reply(t)?.let { (m, txt) -> Persona.mood = m; return Reply(txt, m) }
        return askGemini(ctx, t)
    }

    private fun device(ctx: Context, raw: String): String? {
        val svc = JarvisAccessibilityService.instance
        fun m(p: String) = Regex(p, RegexOption.IGNORE_CASE).find(raw)

        // ---- Confirmation (call/SMS/WhatsApp bhejne se pehle) ----
        Pending.run?.let { run ->
            if (Regex("^(haan|haa|yes|kar do|bhej do|ok|theek hai)\\b", RegexOption.IGNORE_CASE).containsMatchIn(raw)) {
                Pending.clear(); return run()
            }
            if (Regex("^(nahi|no|cancel|mat|ruk)\\b", RegexOption.IGNORE_CASE).containsMatchIn(raw)) {
                Pending.clear(); return "Theek hai, cancel kar diya."
            }
        }

        // ---- Message reply / smart reading ----
        m("^reply (.+)$")?.let {
            val who = NotifService.lastSender
            if (who.isEmpty()) return "Kisko reply karun? Pehle koi message aane do."
            return confirmSend(ctx, who, it.groupValues[1], NotifService.lastPkg == "com.whatsapp")
        }
        m("^message padh ke batao (on|chalu karo)$")?.let {
            ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("smart_read", true).apply()
            return "Message padh ke batana ON kar diya."
        }
        m("^message padh ke batao (off|band karo)$")?.let {
            ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("smart_read", false).apply()
            return "Message padh ke batana OFF kar diya."
        }

        // ---- Termux: user ke confirm ke baad hi command chalegi ----
        m("^termux (?:mein|me|pe) (.+)$")?.let {
            val cmd = it.groupValues[1].trim()
            Pending.set("termux") { Termux.run(ctx, cmd) }
            return "Termux mein ye command chalaun? `$cmd`\n'haan' ya 'nahi' bolo."
        }
        m("^termux install (.+)$")?.let {
            val cmd = "pkg install -y " + it.groupValues[1].trim()
            Pending.set("termux") { Termux.run(ctx, cmd) }
            return "Termux mein ye install karun? `$cmd`\n'haan' ya 'nahi' bolo."
        }

        // ---- Monster band karna ----
        m("^(?:monster|jarvis) band karo$")?.let {
            val mon = MonsterActivity.instance
            return if (mon == null) "Monster khula hi nahi hai." else { mon.finish(); "Monster band kar diya." }
        }

        // ---- Notifications ----
        m("^notifications? (?:padho|dikhao|batao|check karo)$")?.let {
            val n = NotifService.latest(5)
            return if (n.isEmpty()) "Koi nayi notification nahi hai (ya Notification access OFF hai)."
                   else n.joinToString("\n") { "• $it" }
        }

        // ---- Files: PDF, Word, Excel ----
        m("^(pdf|docx|word|excel|xlsx) (?:banao|bana do) (.+)$")?.let {
            return makeFile(ctx, it.groupValues[1].lowercase(), it.groupValues[2])
        }
        // ---- Image generation ----
        m("^(?:image|photo|tasveer) (?:banao|bana do) (.+)$")?.let {
            return makeImage(ctx, it.groupValues[1])
        }
        // ---- Monster page ----
        m("^(?:monster|hologram) (?:kholo|khol do|dikhao)$")?.let {
            ctx.startActivity(Intent(ctx, MonsterActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Monster khol diya."
        }

        // ---- Play Store / Google APK (install user khud confirm karega) ----
        m("^(?:play ?store|playstore) (?:pe|par|pr) (.+?)(?: (?:install|download))?(?: karo| kar do)?$")?.let {
            return PhoneTools.playStore(ctx, it.groupValues[1].trim())
        }
        m("^google (?:se|pe|par) (.+?) apk (?:dhoondo|dhundo|search karo)$")?.let {
            return PhoneTools.googleApk(ctx, it.groupValues[1].trim())
        }
        m("^(.+?) (?:install|download) karo$")?.let {
            return PhoneTools.playStore(ctx, it.groupValues[1].trim())
        }

        // ---- Photos: dekhna, delete (confirm ke saath), WhatsApp share, click ----
        m("^(?:aaj ki |latest |recent )?(?:photos?|tasveer(?:en)?) (?:dikhao|dekho|batao)$")?.let {
            return PhoneTools.listPhotos(ctx)
        }
        m("^(?:(\\d+) )?(?:latest |ye |yeh |purani )?(?:photos?|tasveer(?:en)?) delete karo$")?.let {
            val n = it.groupValues[1].toIntOrNull()?.coerceIn(1, 10) ?: 1
            return PhoneTools.askDelete(ctx, n)
        }
        m("^(?:ye |yeh |latest )?(?:photo|tasveer) (?:whatsapp|whats app) (?:par|pe) (?:bhejo|share karo)$")?.let {
            return PhoneTools.shareLatestToWhatsApp(ctx)
        }
        m("^(?:photo|tasveer) (?:lo|kheencho|khicho|click karo)$")?.let {
            return PhoneTools.openCameraForPhoto(ctx)
        }

        // ---- Media apps ----
        m("^youtube (?:pe|par) (.+?)(?: chalao| search karo)?$")?.let {
            val q = it.groupValues[1]
            openUri(ctx, "https://www.youtube.com/results?search_query=" + enc(q), "com.google.android.youtube")
            return "YouTube pe \"$q\" khol diya. Video tap karo, phir bolo 'aage' ya 'peeche'."
        }
        m("^spotify (?:pe|par) (.+?)(?: chalao| bajao)?$")?.let {
            val q = it.groupValues[1]
            openUri(ctx, "spotify:search:" + enc(q), "com.spotify.music")
            return "Spotify pe \"$q\" khol diya."
        }
        m("^(?:pause|rok do|ruko|play|chalao|chala do)$")?.let {
            if (svc == null) return NO_SERVICE
            if (svc.clickText("Pause") || svc.clickText("Play")) return "Ho gaya."
            mediaKey(ctx); return "Play/pause bheja."
        }
        m("^(?:10 second )?aage(?: 10 second)?$")?.let { return act(svc) { s -> s.doubleTapSide(true); true } }
        m("^(?:10 second )?peeche(?: 10 second)?$")?.let { return act(svc) { s -> s.doubleTapSide(false); true } }

        // ---- Phone control ----
        m("^(?:wapas|back)$")?.let { return act(svc) { s -> s.back(); true } }
        m("^(?:home|home jao)$")?.let { return act(svc) { s -> s.home(); true } }
        m("^recents?$")?.let { return act(svc) { s -> s.recents(); true } }
        m("^scroll (neeche|niche|upar)$")?.let {
            val fwd = it.groupValues[1] != "upar"
            return act(svc) { s -> s.scroll(fwd) }
        }
        m("^(?:type karo|likho) (.+)$")?.let {
            val txt = it.groupValues[1]
            return act(svc) { s -> s.typeText(txt) }
        }
        m("^(?:notification|notifications) (?:kholo|khol do)$")?.let { return act(svc) { s -> s.notifications(); true } }
        m("^(.+?) (?:kholo|khol do|open karo)$")?.let { return openApp(ctx, it.groupValues[1]) }

        // ---- Volume / torch / brightness / battery ----
        m("^volume (badhao|up)$")?.let { volume(ctx, AudioManager.ADJUST_RAISE); return "Volume badha diya." }
        m("^volume (kam karo|down)$")?.let { volume(ctx, AudioManager.ADJUST_LOWER); return "Volume kam kar diya." }
        m("^torch (on|chalu karo|jalao)$")?.let { return Device.torch(ctx, true) }
        m("^torch (off|band karo|bujhao)$")?.let { return Device.torch(ctx, false) }
        m("^brightness (\\d+)")?.let { return Device.brightness(ctx, it.groupValues[1].toInt()) }
        m("^brightness full$")?.let { return Device.brightness(ctx, 100) }
        m("^battery(?: kitni hai)?$")?.let { return Device.battery(ctx) }

        // ---- Time / alarm / timer ----
        m("^(\\d+) minute ka timer$")?.let {
            val mins = it.groupValues[1].toInt()
            return try {
                ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, mins * 60)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS timer")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "$mins minute ka timer laga diya."
            } catch (e: Exception) { "Clock app mein timer set nahi hua." }
        }
        m("^(?:subah|raat|shaam|dopahar)? ?(\\d{1,2}) baje alarm(?: laga do| lagao)?$")?.let {
            var h = it.groupValues[1].toInt()
            val part = raw.lowercase()
            if ((part.contains("raat") || part.contains("shaam")) && h < 12) h += 12
            return Device.alarm(ctx, h, 0)
        }
        m("^(time kya|samay kya|time)$")?.let {
            return "Abhi " + SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date())
        }
        m("^(aaj ki date|date kya|date)$")?.let {
            return SimpleDateFormat("dd MMMM yyyy, EEEE", Locale("hi", "IN")).format(Date())
        }

        // ---- Calls / SMS / WhatsApp ----
        m("^(.+?) ko call (?:karo|kar do|laga do)$|^call (.+)$")?.let {
            val name = it.groupValues[1].ifEmpty { it.groupValues[2] }
            val c = Device.findContact(ctx, name) ?: return "$name contacts mein nahi mila (ya contacts permission nahi hai)."
            Pending.set("call") { Device.call(ctx, name) }
            return "${c.first} ko call karun? 'haan' ya 'nahi' bolo."
        }
        m("^(.+?) ko sms (?:bhejo|bhej do) (.+)$")?.let {
            return confirmSend(ctx, it.groupValues[1], it.groupValues[2], false)
        }
        m("^(.+?) ko whatsapp (?:message )?(?:bhejo|bhej do) (.+)$")?.let {
            return confirmSend(ctx, it.groupValues[1], it.groupValues[2], true)
        }
        m("^sms padho$")?.let { return Device.readSms(ctx) }
        m("^clipboard(?: padho)?$")?.let { return Device.clipboard(ctx) }

        // ---- Mausam ----
        m("^mausam(?: kaisa hai| kaisa)?(?: (.+))?$")?.let {
            val city = it.groupValues[1].ifEmpty { "Delhi" }
            return Device.weather(city)
        }

        // ---- Yaad / notes ----
        m("^yaad rakho (.+)$")?.let { Memory.addFact(ctx, it.groupValues[1]); return "Theek hai, yaad rakh liya." }
        m("^kya yaad hai$")?.let {
            val f = Memory.facts(ctx)
            return if (f.isEmpty()) "Abhi kuch yaad nahi hai." else f.joinToString("\n") { "• $it" }
        }
        m("^sab bhool jao$")?.let { Memory.clearFacts(ctx); return "Ho gaya, sab bhool gaya." }
        m("^note karo (.+)$")?.let { Memory.addNote(ctx, it.groupValues[1]); return "Note kar liya." }
        m("^mere notes$")?.let {
            val n = Memory.notes(ctx)
            return if (n.isEmpty()) "Koi note nahi hai." else n.joinToString("\n") { "• $it" }
        }

        // ---- Mood khud badalna ----
        m("^mood badlo$")?.let {
            Persona.mood = Mood.values().random()
            return "Lo, mood ab ${Persona.mood.name.lowercase()} ${Persona.mood.emoji}"
        }
        return null
    }

    private fun gKey(ctx: Context): String? = SecurePrefs.geminiKey(ctx)

    private fun makeFile(ctx: Context, kind: String, topic: String): String {
        val key = gKey(ctx) ?: return "File banane ke liye Gemini key chahiye (Settings ⚙)."
        return try {
            when (kind) {
                "pdf" -> {
                    val body = Gemini.text(key, "Is topic par saaf, achha content likho (headings aur points ke saath). Sirf content do, koi intro ya mood tag nahi. Topic: $topic")
                    "PDF bana di: " + FileMaker.pdf(ctx, topic, body).absolutePath
                }
                "docx", "word" -> {
                    val body = Gemini.text(key, "Is topic par Word document ka content likho, paragraphs mein. Sirf content do. Topic: $topic")
                    "Word file bana di: " + FileMaker.docx(ctx, topic, body).absolutePath
                }
                else -> {
                    val csv = Gemini.text(key, "Is topic par spreadsheet ke liye data do: pehli line header, har line comma-separated. Koi markdown ya code block nahi. Topic: $topic")
                        .replace("```", "").trim()
                    "Excel bana diya: " + FileMaker.xlsx(ctx, topic, csv).absolutePath
                }
            }
        } catch (e: Exception) { "File nahi bani: ${e.message}" }
    }

    private fun makeImage(ctx: Context, prompt: String): String {
        val key = gKey(ctx) ?: return "Image ke liye Gemini key chahiye (Settings ⚙)."
        return try {
            val bytes = Gemini.image(key, prompt)
            val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "img_${System.currentTimeMillis()}.png")
            f.writeBytes(bytes)
            "Image bana di: ${f.absolutePath}"
        } catch (e: Exception) { "Image nahi bani: ${e.message}" }
    }

    private fun confirmSend(ctx: Context, who: String, msg: String, wa: Boolean): String {
        val c = Device.findContact(ctx, who) ?: return "$who contacts mein nahi mila."
        val label = if (wa) "WhatsApp" else "SMS"
        Pending.set(label) { if (wa) Device.whatsapp(ctx, who, msg) else Device.sms(ctx, who, msg) }
        return "${c.first} ko $label: \"$msg\" bhejun? 'haan' ya 'nahi' bolo."
    }

    private fun factsStr(ctx: Context): String = Memory.facts(ctx).joinToString("; ").ifEmpty { "kuch nahi" }

    /** Naya notification aaya: kisne bheja, kya bola, opinion, reply options. */
    fun analyzeMessage(ctx: Context, app: String, sender: String, msg: String): Reply {
        val key = gKey(ctx) ?: return Reply("$app pe $sender ka message aaya: $msg. Opinion ke liye Gemini key daalo.", Mood.CHILL)
        return try {
            val prompt = Persona.systemPrompt(factsStr(ctx)) + "\n\nAb ye notification aaya hai:\nApp: $app\nKisne bheja: $sender\nMessage: $msg\n\n" +
                "Hinglish mein, dost ki tarah, is format mein jawab do: (1) kisne bheja aur kya bola, ek line mein. (2) tera opinion, emotion ke saath. (3) reply ke 2 chhote options. Pehli line mood tag. Kuch bhejne ka faisla mat karo, bas suggest karo."
            val (mood, text) = Persona.parse(Gemini.text(key, prompt))
            mood?.let { Persona.mood = it }
            Reply("$app pe $sender ka message: $text", mood ?: Persona.mood)
        } catch (e: Exception) {
            Reply("$app pe $sender ka message: $msg", Mood.CHILL)
        }
    }

    /** Photo ko dekh ke jawab. */
    fun vision(ctx: Context, jpg: ByteArray, q: String): Reply {
        val key = gKey(ctx) ?: return Reply("Photo dekhne ke liye Gemini key chahiye (Settings ⚙).", Mood.SAD)
        return try {
            val prompt = Persona.systemPrompt(factsStr(ctx)) +
                "\n\nUser ne ye photo bheji aur pucha: \"$q\". Pehle mood tag, phir seedha jawab, dost wale andaaz mein. Jo dikh raha hai wahi bolo, andaaz mat lagao."
            val (mood, text) = Persona.parse(Gemini.vision(key, prompt, jpg))
            mood?.let { Persona.mood = it }
            Reply(text, mood ?: Persona.mood)
        } catch (e: Exception) {
            Reply("Photo samajh nahi aayi: ${e.message}", Mood.SAD)
        }
    }

    private fun act(svc: JarvisAccessibilityService?, block: (JarvisAccessibilityService) -> Boolean): String {
        if (svc == null) return NO_SERVICE
        return if (block(svc)) "Ho gaya." else "Ye kaam abhi nahi hua."
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun openUri(ctx: Context, uri: String, pkg: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i.setPackage(pkg)) }
        catch (e: Exception) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val pkg = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, ignoreCase = true)
        }?.packageName ?: return "$name naam ka app nahi mila."
        val i = pm.getLaunchIntentForPackage(pkg) ?: return "$name khul nahi sakta."
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "$name khol diya."
    }

    private fun volume(ctx: Context, dir: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun mediaKey(ctx: Context) {
        ctx.sendOrderedBroadcast(Intent(Intent.ACTION_MEDIA_BUTTON)
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)), null)
    }

    /** Gemini sirf tab jab local/device se kuch na bane. History + facts + mood saath bheje jaate hain. */
    private fun askGemini(ctx: Context, q: String): Reply {
        val key = SecurePrefs.geminiKey(ctx) ?: ""
        ensureHistory(ctx)
        if (key.isEmpty()) return Reply("Dost, Gemini key nahi daali. Settings (⚙) mein daal de, tab tak chhoti baatein aur phone commands chalenge.", Mood.SAD)

        val facts = Memory.facts(ctx).joinToString("; ").ifEmpty { "kuch nahi" }
        history.add("user" to q)
        return try {
            val contents = JSONArray()
            history.takeLast(12).forEach { (role, text) ->
                contents.put(JSONObject()
                    .put("role", if (role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text))))
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", Persona.systemPrompt(facts)))))
                .put("contents", contents)
            val (mood, text) = Persona.parse(post(key, body))
            history.add("model" to text)
            trimHistory()
            saveHistory(ctx)
            if (mood != null) Persona.mood = mood
            Reply(text, mood ?: Persona.mood)
        } catch (e: Exception) {
            history.removeAt(history.size - 1)
            Reply("Net ya key mein dikkat hai: ${e.message}", Mood.SAD)
        }
    }

    private fun post(key: String, body: JSONObject): String = Gemini.textFrom(Gemini.run(key, body))

    private var historyLoaded = false

    private fun ensureHistory(ctx: Context) {
        if (historyLoaded) return
        historyLoaded = true
        val raw = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("chat_history", "[]") ?: "[]"
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                history.add(o.getString("role") to o.getString("text"))
            }
        } catch (_: Exception) { }
    }

    private fun trimHistory() {
        while (history.size > 40) history.removeAt(0)
    }

    private fun saveHistory(ctx: Context) {
        val a = JSONArray()
        history.forEach { a.put(JSONObject().put("role", it.first).put("text", it.second)) }
        ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putString("chat_history", a.toString()).apply()
    }
}

/** Jo kaam user ki 'haan' ka wait kar raha hai (call / SMS / WhatsApp). */
object Pending {
    @Volatile var run: (() -> String)? = null
    fun set(label: String, action: () -> String) { run = action }
    fun clear() { run = null }
}

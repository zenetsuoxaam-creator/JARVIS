package com.jarvis.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * API key encrypted store mein rakhi jaati hai (Android Keystore se encrypted).
 * Pehle ki plain-text key ko ek baar migrate karke purani jagah se hata deta hai.
 */
object SecurePrefs {
    private const val FILE = "jarvis_secure"
    private const val KEY_GEMINI = "gemini_key"

    @Volatile private var cached: SharedPreferences? = null

    private fun prefs(ctx: Context): SharedPreferences {
        cached?.let { return it }
        val app = ctx.applicationContext
        val master = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        val p = EncryptedSharedPreferences.create(
            app, FILE, master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        cached = p
        return p
    }

    private fun migrate(ctx: Context) {
        val old = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val k = old.getString(KEY_GEMINI, null) ?: return
        if (k.isNotEmpty()) prefs(ctx).edit().putString(KEY_GEMINI, k).apply()
        old.edit().remove(KEY_GEMINI).apply()
    }

    fun geminiKey(ctx: Context): String? {
        migrate(ctx)
        return prefs(ctx).getString(KEY_GEMINI, "")?.takeIf { it.isNotEmpty() }
    }

    fun setGeminiKey(ctx: Context, key: String) {
        prefs(ctx).edit().putString(KEY_GEMINI, key).apply()
    }
}

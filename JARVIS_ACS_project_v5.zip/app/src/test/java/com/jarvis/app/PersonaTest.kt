package com.jarvis.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PersonaTest {
    @Test
    fun parsesMoodTagAndStripsIt() {
        val (mood, text) = Persona.parse("[mood:HAPPY] Chal yaar")
        assertEquals(Mood.HAPPY, mood)
        assertEquals("Chal yaar", text)
    }

    @Test
    fun replyWithoutTagKeepsText() {
        val (mood, text) = Persona.parse("  seedha jawab  ")
        assertNull(mood)
        assertEquals("seedha jawab", text)
    }

    @Test
    fun detectsSadUserMood() {
        assertEquals(Mood.SAD, Persona.moodFromUser("aaj main udaas hoon"))
    }
}
